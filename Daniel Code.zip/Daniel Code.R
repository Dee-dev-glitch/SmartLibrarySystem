# DTS 204 - Statistical Computing, Inference and Modelling
# Lab Assessment: Palmer Penguins Dataset
# Author: Daniel
# Date: July 2026

# Load packages
library(palmerpenguins)
library(ggplot2)
library(corrplot)

# -------------------------------
# Task 1: Data Exploration
# -------------------------------
data("penguins")
head(penguins)
colSums(is.na(penguins))
summary(penguins)
sapply(penguins[, c("bill_length_mm","bill_depth_mm","flipper_length_mm","body_mass_g")], sd, na.rm=TRUE)

# -------------------------------
# Task 2: Hypothesis Testing
# -------------------------------
adelie <- subset(penguins, species == "Adelie")$body_mass_g
gentoo <- subset(penguins, species == "Gentoo")$body_mass_g
t.test(adelie, gentoo, var.equal = TRUE)

male_count <- sum(penguins$sex == "male", na.rm=TRUE)
total_count <- sum(!is.na(penguins$sex))
prop.test(male_count, total_count, p=0.5)

# -------------------------------
# Task 3: Correlation Analysis
# -------------------------------
num_vars <- penguins[, c("bill_length_mm","bill_depth_mm","flipper_length_mm","body_mass_g")]
cor_matrix <- cor(num_vars, use="complete.obs")
corrplot(cor_matrix, method="color", addCoef.col="black")

# -------------------------------
# Task 4: Regression Modeling
# -------------------------------
model_simple <- lm(body_mass_g ~ flipper_length_mm, data=penguins)
summary(model_simple)

model_multi <- lm(body_mass_g ~ flipper_length_mm + bill_length_mm + bill_depth_mm, data=penguins)
summary(model_multi)

# -------------------------------
# Task 5: Visualization
# -------------------------------
ggplot(penguins, aes(x=flipper_length_mm, y=body_mass_g)) +
  geom_point() +
  geom_smooth(method="lm", col="blue") +
  labs(title="Body Mass vs Flipper Length")

ggplot(penguins, aes(x=species, y=body_mass_g, fill=species)) +
  geom_boxplot() +
  labs(title="Distribution of Body Mass by Species")

ggplot(penguins, aes(x=body_mass_g)) +
  geom_histogram(aes(y=..density..), bins=30, fill="lightblue", color="black") +
  stat_function(fun=dnorm, args=list(mean=mean(penguins$body_mass_g, na.rm=TRUE),
                                     sd=sd(penguins$body_mass_g, na.rm=TRUE)),
                col="red") +
  labs(title="Histogram of Body Mass with Normal Curve")

